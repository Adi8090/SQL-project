SELECT name FROM songs
WHERE artist_id = 54;
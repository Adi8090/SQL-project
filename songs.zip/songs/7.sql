SELECT AVG(energy) FROM songs
 WHERE artist_id = 23;